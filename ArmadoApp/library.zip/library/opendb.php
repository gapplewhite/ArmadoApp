<?php
$conn = mysqli_connect ($dbhost, $dbuser, $dbpass,$dbname) or die ('I cannot connect to the database because: ' . mysql_error());
//mysqli_query("SET NAMES 'utf8'");
//mysql_select_db ($dbname);
?>