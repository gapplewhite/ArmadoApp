<?php
//mysql_free_result($result);
mysql_close($conn);
?>