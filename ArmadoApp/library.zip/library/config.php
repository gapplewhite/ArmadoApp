<?php
// db properties


$dbhost = 'localhost';
$dbuser = 'gerardo6_admin'; 
$dbpass = 'Panama01';
$dbname = 'gerardo6_TicketCentracom';
$dbname2 = 'robo';

?>